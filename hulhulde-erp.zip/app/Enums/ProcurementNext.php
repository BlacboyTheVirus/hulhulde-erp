<?php
namespace App\Enums;
class ProcurementNext extends AbstractEnum
{
    const SECURITY = 'security';
    const WEIGHBRIDGE = 'weighbridge';
    const QUALITY = 'quality';
    const WAREHOUSE = 'warehouse';
    const ACCOUNT = 'account';
}
