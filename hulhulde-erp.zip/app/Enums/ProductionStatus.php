<?php
namespace App\Enums;
class ProductionStatus extends AbstractEnum
{
    const OPEN = 'open';
    const CLOSE = 'close';
}
