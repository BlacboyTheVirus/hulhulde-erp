<?php
namespace App\Enums;
class ProcurementStatus extends AbstractEnum
{
    const OPEN = 'open';
    const CLOSE = 'close';
}
