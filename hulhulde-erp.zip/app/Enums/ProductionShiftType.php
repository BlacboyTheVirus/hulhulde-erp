<?php
namespace App\Enums;
class ProductionShiftType extends AbstractEnum
{
    const MORNING = 'morning';
    const NIGHT = 'night';

}
