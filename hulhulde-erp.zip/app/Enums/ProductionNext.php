<?php
namespace App\Enums;
class ProductionNext extends AbstractEnum
{
    const WAREHOUSE = 'warehouse';
    const OUTPUT = 'output';
    const STORE = 'store';
}
