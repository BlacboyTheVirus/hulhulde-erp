<?php $__env->startSection('title', 'Edit Permissions | Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Edit Permission</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="container-fluid">
    <div class="row">
        <div id="errorBox"></div>
        <div class="col-3">
            <form method="POST" action="<?php echo e(route('users.permissions.update', $permission->id)); ?>"  id="updateform" >
                <?php echo method_field('patch'); ?>
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <h5>Update</h5>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="name" class="form-label">Name <span class="text-danger">*</span></label>
                            <input type="text" id="name" class="form-control" name="name" placeholder="Enter Permission Name" value="<?php echo e($permission->name); ?>">
                        </div>
                    </div>
                    <div class="card-footer">
                        <button id="update" class="btn btn-primary" >Update</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $.ajaxSetup({
            headers:{
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        })


        $(document).ready(function(){
            //validate
            var formvalidator = $('#updateform').validate({
                    rules: {
                        name: {
                            required: true,
                        },                        
                    },
                    messages: {
                        name: {
                            name: "Please enter a valid permission name"
                        },
                    },
                    errorElement: 'span',
                    errorPlacement: function (error, element) {
                        error.addClass('invalid-feedback');
                        element.closest('.form-group').append(error);
                    },
                    highlight: function (element, errorClass, validClass) {
                        $(element).addClass('is-invalid');
                    },
                    unhighlight: function (element, errorClass, validClass) {
                        $(element).removeClass('is-invalid');
                    }
                });
            
            //submit form

            $('#update').click(function(e){
                e.preventDefault();

                if(!formvalidator.form()){
                    return false;
                };
                
                
                //submit
                var formData = {
                    name: $("#name").val(),
                    id:<?php echo e($permission->id); ?>,
                };

               
                $.ajax({
                    type: "PUT",
                    url: '<?php echo e(route('users.permissions.update', $permission)); ?>',
                    data: formData,
                    dataType: "json",
                    encode: true,
                    success:  function (response) {
                                if (response.success){
                                    $('#updateform').trigger('reset');
                                    sweetToast('', response.message, 'success', true);
                                    setTimeout(() => {
                                         window.location.href = '<?php echo e(route('users.permissions.index')); ?>';
                                     }, 1000);

                                } else {
                                    sweetToast('', response.message, 'error', true);
                                }
                            },
                    error:     function (response){
                                    sweetToast('', 'Sorry, something went wrong! Please try again.', 'error', true); 
                            }
                
                });
                
            });


           
            
            
        }); // end document ready

    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Sweetalert2', true); ?>
<?php $__env->startSection('plugins.jQueryValidation', true); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\hulhulde-erp\resources\views/users/permissions/edit.blade.php ENDPATH**/ ?>