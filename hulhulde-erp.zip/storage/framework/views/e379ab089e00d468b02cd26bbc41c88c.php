<?php $__env->startSection('title', 'Roles | Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Roles</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="container-fluid">
       <div id="errorBox"></div>
       <div class="card">
           <div class="card-header">
               <div class="card-title">
                   <h5>List</h5>
               </div>
               <a class="float-right btn btn-primary btn-sm m-0" href="<?php echo e(route('users.roles.create')); ?>"><i class="fas fa-plus"></i> Add</a>
           </div>
           <div class="card-body">
               <!--DataTable-->
               <div class="table-responsive">
                   <table id="tblData" class="table table-bordered table-striped dataTable dtr-inline">
                       <thead>
                           <tr>
                               <th>ID</th>
                               <th>Name</th>
                               <th>Users</th>
                               <th>Permission</th>
                               <th>Action</th>
                           </tr>
                       </thead>
                   </table>
               </div>
           </div>
       </div>
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $.ajaxSetup({
        headers:{
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    })
    $(document).ready(function(){
        var table = $('#tblData').DataTable({
            reponsive:true, processing:true, serverSide:true, autoWidth:false, 
            ajax:"<?php echo e(route('users.roles.index')); ?>", 
            columns:[
                {data:'id', name:'id'},
                {data:'name', name:'name'},
                {data:'users_count', name:'users_count', className:"text-center"},
                {data:'permissions_count', name:'permissions_count', className:"text-center"},
                {data:'action', name:'action', bSortable:false, className:"text-center"},
            ], 
            order:[[0, "desc"]], 
            bDestory:true,
        });

        // Delete button clicked 
        $('body').on('click', '#btnDel', function(){
            //confirmation
            var id = $(this).data('id');
            if(confirm('Delete Data '+id+'?')==true)
            {
                var route = "<?php echo e(route('users.roles.destroy', ':id')); ?>"; 
                route = route.replace(':id', id);
                $.ajax({
                    url: route, 
                    type:"delete", 
                    success:function(response){
                        //console.log(response);
                        sweetToast('', response.message, 'success', true);
                        $("#tblData").DataTable().ajax.reload();
                    },
                    error:function(response){
                        sweetToast('', response.message, 'error', true);
                    }
                });
            }else{
                //do nothing
            }
        });

        
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>
<?php $__env->startSection('plugins.jQueryValidation', true); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\hulhulde-erp\resources\views/users/roles/index.blade.php ENDPATH**/ ?>