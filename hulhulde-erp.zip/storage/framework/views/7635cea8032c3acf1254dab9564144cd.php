<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">

                <div class="card-header">
                    <div class="card-title">
                        <div class="row">
                            <div class="col-md-12 ">&nbsp;</div>












                        </div>
                    </div>
                </div>



                <div class="card-body">

                    <div class="row">

                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-info">
                                <div class="inner">
                                    <h3 class="font-weight-bold">
                                        <span id="paddy_quantity"><?php echo e($paddy_procured); ?></span>
                                        <sup style="font-size: 20px">tons</sup>
                                    </h3>
                                    <p>Paddy Procured</p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-shopping-cart"></i>
                                </div>
                                <a href="<?php echo e(route('procurement.warehouse.index')); ?>" class="small-box-footer">
                                    More info <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-success">
                                <div class="inner">
                                    <h3 class="font-weight-bold">
                                        <span id="procurements"><?php echo e($procurements); ?></span></h3>
                                    <p>No of Procurements</p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-money-bill-wave-alt"></i>
                                </div>
                                <a href="<?php echo e(route('procurement.index')); ?>" class="small-box-footer">
                                    More info <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>



                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-primary">
                                <div class="inner">
                                    <h3 class="font-weight-bold">
                                        <sup style="font-size: 20px">₦</sup>
                                        <span id="procurements"><?php echo e(number_format($payments,0,'.',',')); ?></span></h3>
                                    <p>Procurement Payments</p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-money-bill-wave-alt"></i>
                                </div>
                                <a href="<?php echo e(route('procurement.index')); ?>" class="small-box-footer">
                                    More info <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>

                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-pink">
                                <div class="inner">
                                    <h3 class="font-weight-bold">
                                        <span id="available_paddy"><?php echo e($paddy_quantity); ?></span></h3>
                                    <p>Available Paddy</p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-money-bill-wave-alt"></i>
                                </div>
                                <a href="<?php echo e(route('procurement.warehouse.index')); ?>" class="small-box-footer">
                                    More info <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>





                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-gradient-success">
                                <div class="inner">
                                    <h3 class="font-weight-bold">
                                        <span id="paddy_quantity"><?php echo e($processed_paddy); ?></span>
                                        <sup style="font-size: 20px">tons</sup>
                                    </h3>
                                    <p>Paddy Processed</p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-shopping-cart"></i>
                                </div>
                                <a href="<?php echo e(route('production.index')); ?>" class="small-box-footer">
                                    More info <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>


                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-default">
                                <div class="inner">
                                    <h3 class="font-weight-bold">
                                        <span id="procurements"><?php echo e($productions); ?></span></h3>
                                    <p>Production</p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-money-bill-wave-alt"></i>
                                </div>
                                <a href="<?php echo e(route('procurement.index')); ?>" class="small-box-footer">
                                    More info <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>



                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-gradient-success">
                                <div class="inner">
                                    <h3 class="font-weight-bold">
                                        <span id="paddy_quantity"><?php echo e($invoices_count); ?></span>
                                    </h3>
                                    <p>Total Invoice</p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-shopping-cart"></i>
                                </div>
                                <a href="<?php echo e(route('marketing.invoice.index')); ?>" class="small-box-footer">
                                    More info <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>


                        <div class="col-lg-3 col-6">
                            <div class="small-box bg-orange">
                                <div class="inner">
                                    <h3 class="font-weight-bold">
                                        <sup style="font-size: 20px">₦</sup>
                                        <span id="available_paddy"><?php echo e(number_format($invoices_amount, 0,'',',')); ?></span></h3>
                                    <p>Total Invoice Amount</p>
                                </div>
                                <div class="icon">
                                    <i class="fa fa-money-bill-wave-alt"></i>
                                </div>
                                <a href="<?php echo e(route('procurement.index')); ?>" class="small-box-footer">
                                    More info <i class="fas fa-arrow-circle-right"></i>
                                </a>
                            </div>
                        </div>


                    </div> <!-- ROW -->

                    <div class="row">

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 col-sm-6 col-md-3">
                            <div class="info-box">
                                <span class="info-box-icon bg-secondary elevation-1"><i class="fas fa-store"></i></span>
                                <div class="info-box-content">
                                    <span class="info-box-text"><?php echo e($product->name); ?></span>
                                    <h3 class="info-box-number" id="invoice_count"><?php echo e($product->bags); ?></h3>
                                    <sup style="font-size: 12px; float: left">bags</sup>
                                </div>

                            </div>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>




                </div>
            </div>
        </div>
    </div>
    <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\hulhulde-erp\resources\views/dashboard.blade.php ENDPATH**/ ?>