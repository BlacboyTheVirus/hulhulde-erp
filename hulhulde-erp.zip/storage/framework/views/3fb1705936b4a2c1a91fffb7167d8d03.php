<?php $__env->startSection('title', 'Production Outputs | Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Create Outputs</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div id="errorBox"></div>
            <div class="col-md-6">
                <form method="POST" action="<?php echo e(route('production.output.store')); ?>" id="newform">
                    <?php echo csrf_field(); ?>
                    <div class="card card-info card-outline">
                        <div class="card-header">
                            <div class="card-title">
                                <h5>Add Outputs for <?php echo e($data['production_code']); ?></h5>
                            </div>
                        </div>


                        <div class="card-body">


                            <div class="row mb-3">

                                <div class="col-md-3 col-sm-3 border-right">
                                    <div class="description-block">
                                        <span class="description-text">PRODUCTION CODE</span>
                                        <h5 class="description-header"><?php echo e($data['production_code']); ?></h5>

                                    </div>
                                </div>

                                <div class="col-md-3 col-sm-3 border-right">
                                    <div class="description-block">
                                        <span class="description-text">PADDY RELEASED</span>
                                        <h5 class="description-header" id="paddy_weight"><?php echo e($data['weight']); ?></h5>
                                    </div>

                                </div>


                                <div class="col-md-3 col-sm-3 ">
                                    <div class="description-block">
                                        <span class="description-text">PRODUCTION DATE</span>
                                        <h5 class="description-header"><?php echo e($data['production_date']); ?></h5>
                                    </div>

                                </div>

                            </div>


                            <input type="hidden" name="production_id" value="<?php echo e($data['production_id']); ?>" >


                            <div id="output-list">
                                <?php $__currentLoopData = $outputs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $output): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="btn btn-app add-output" id="outputbtn_<?php echo e($output->id); ?>" data-id="<?php echo e($output->id); ?>"  data-name="<?php echo e($output->name); ?>"  data-bagweight="<?php echo e($output->bag_weight); ?>">
                                        <i class="fas fa-barcode"></i> <?php echo e($output->name); ?>

                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            <div class="form-group">
                                <label>Date:</label>
                                <div class="input-group date" id="production-date" data-target-input="nearest">
                                    <input type="text" class="form-control " name="production_date" id="production_date" placeholder="Production Date" value="" readonly required style="background: #fff !important">
                                    <div class="input-group-append" data-target="#production-date" data-toggle="datetimepicker">
                                        <div class="input-group-text"><i class="fa fa-calendar-alt"></i></div>
                                    </div>
                                </div>
                            </div>



                            <div class="form-group">
                                <label for="payment_type" class="form-label">Shift</label>
                                <select class="form-control select2" id="shift" data-placeholder="Select Production Shift"
                                        name="shift">
                                    <option value="">--Select Shift--</option>
                                        <?php $__currentLoopData = \App\Enums\ProductionShiftType::getValues(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <option value="<?php echo e($shift_type); ?>"><?php echo e(ucfirst($shift_type)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>


                            <label style="font-weight: bold; margin-bottom: 0rem !important;">No. of Bags</label>

                            <div id="output-items" >

                            </div>

                        </div> <!-- Card body -->

                        <div class="card-footer">
                            <button id="save" class="btn btn-primary" >Save</button>
                        </div>
                    </div>
                </form>
            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>

        $(function () {
            $('#shift').select2();
        });

        $(document).ready(function(){




            var count=0;

            $('#output-list').on('click', '.add-output', function (e) {

                e.preventDefault();
                count++;
                console.log (count);
                var output_id = $(this).attr('data-id');
                var output_name = $(this).attr('data-name');
                var output_bag_weight = $(this).attr('data-bagweight');

                // insert the input field
                var output_item = `

                            <div class="form-group outlist" id="output_${output_id}">
                                    <div class="input-group"  >

                                    <div class="input-group-prepend" >
                                        <div class="input-group-text">${output_name}</div>
                                    </div>

                                    <input type="number" class="form-control col-md-12" name="bags[]" id="bags_${count}" placeholder="Bags" value="" required>

                                    <input type="hidden"  name="bag_weight[]"  value="${output_bag_weight}"  id="bag_weight_${output_id}" >


                                    <input type="hidden"  name="output_id[]"   value="${output_id}" >


                                    <div class="input-group-append"  >
                                        <a class="btn btn-danger btn-sm remove-output"  onclick="removeoutput(${output_id})"><i class="fa fa-times"></i></a>
                                    </div>

                                </div>
                            </div>
                `;

                $('#output-items').append(output_item);

                //disable button
                //$(this).prop('disabled', true);
                $(this).hide();
            });



            //VALIDATE FORM
            var formvalidator = $('#newform').validate({
                rules: {

                    weight: {
                        required: true,
                        number: true,
                    },

                },
                messages: {

                    weight: {
                        required: "Please enter expected weight in tonnes",
                        number: "Please enter only number"
                    },

                },
                errorElement: 'span',
                errorPlacement: function (error, element) {
                    error.addClass('invalid-feedback');
                    element.closest('.form-group').append(error);
                },
                highlight: function (element, errorClass, validClass) {
                    $(element).addClass('is-invalid');
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).removeClass('is-invalid');
                }
            });




            //SUBMIT FORM
            $('#save').click(function(e){
                e.preventDefault();

                var errors = false;

                $("[name^=bags]").each(function(){
                    if($(this).val() === ''){
                        $(this).addClass('is-invalid');
                        // $(this).closest('.form-group').find('span').remove();
                        // $(this).closest('.form-group').append('<span class="text-sm text-danger">Please fill</span>');
                        errors = true;
                       }

                });

                 if(errors) {
                     sweetToast('', 'Sorry, you must fill all field marked red.', 'error', true);
                     return false;
                 }


                 if(!formvalidator.form()) {
                     return false;
                 }

                // check if any item has been added
                var count = $('.outlist ').length;
                if(count < 1){
                    sweetToast('', 'Sorry, you must add at least a output.', 'error', true);
                    return false;
                }



                //submit
                var formData = $('#newform').serializeArray();

                $.ajax({
                    type: "POST",
                    url: '<?php echo e(route('production.output.store')); ?>',
                    data: formData,
                    dataType: "json",
                    encode: true,
                    success:  function (response) {
                        if (response.success){
                            sweetToast('', response.message, 'success', true);
                            setTimeout(() => {
                                window.location.href = '<?php echo e(route('production.output.index')); ?>';
                            }, 1000);
                        } else {
                            sweetToast('', response.message, 'error', true);
                        }

                    },
                    error: function (response){
                        sweetToast('', 'Sorry, something went wrong! Please try again.', 'error', true);
                    }

                });

            });

        }); // end document ready


        function removeoutput(id){
            //$('.add-output[data-id="'+id+'"]').prop('disabled', false);
            $('.add-output[data-id="'+id+'"]').show();
            $('#output_'+id).remove();

        }


        //Date picker
        $('#production_date').datepicker({
            format: "dd-mm-yyyy",
            toggleActive: false,
            autoclose: true,
            todayHighlight: true
        }).datepicker("setDate", new Date());



    </script>


<?php $__env->stopSection(); ?>








<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\hulhulde-erp\resources\views/production/output/create.blade.php ENDPATH**/ ?>