<?php $__env->startSection('title', 'Procurements | Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Create New Procurement</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <style>
        .table td, .table th{
            padding: 0.3em !important;
        }
    </style>

    <div class="container-fluid">
        <div class="row">

            <div class="col-12">


                <div class="invoice p-3 mb-3">

                    <div class="row">
                        <div class="col-12">

                            <div class="callout callout-success mb-4">
                                <img src="<?php echo e(asset('vendor/adminlte/dist/img/AdminLTELogo.png')); ?>" width="30px">
                                <h2 class="float-right  text-lg font-weight-bold"> <?php echo e($procurement->input->name); ?> Procurement</h2>
                            </div>

                        </div>

                    </div>



                    <div class="row">
                        <div class="col-12 mb-3 mt-1">
                            <h4>
                                <i class="fas fa-hashtag"></i> <?php echo e($procurement->code); ?>

                                <small class="float-right"><b>Date:</b> <?php echo e($procurement->procurement_date); ?></small>
                            </h4>
                        </div>

                    </div>


                    <div class="row invoice-info ">


                        <div class="col-sm-3 invoice-col">
                            <address class="text-md">
                                <br>Supplier:
                                <b><?php echo e($procurement->supplier->name); ?></b><br>
                                Phone:
                                <b><?php echo e($procurement->supplier->phone); ?></b><br>
                                Email:
                                <b><?php echo e($procurement->supplier->email); ?></b><br>
                            </address>
                        </div>

                        <div class="col-sm-3 invoice-col">
                            <address class="text-md">
                                <br>Status:
                                <b><?php echo e($procurement->status); ?></b><br>
                                Approval:
                                <b><?php echo e($procurement->approval->status ? "Approved" : "Pending"); ?></b><br>
                                </address>
                        </div>

                        <div class="col-sm-3 invoice-col">
                            <address class="text-md">
                                <br>Account Number:
                                <b><?php echo e($procurement->supplier->bank_account); ?></b><br>
                                Bank Name:
                                <b><?php echo e($procurement->supplier->bank_name); ?></b><br>
                            </address>
                        </div>

                        <div class="col-sm-3 invoice-col">
                            <address class="text-md">
                                <br>Total:
                                <b>₦ <?php echo e(number_format($weight * $price,0, '.', ',')); ?></b><br>
                                Paid:
                                <b>₦ <?php echo e(number_format($procurement->payments->sum('amount'), 0,'.',',')); ?></b><br>

                                Balance:
                                <b>₦ <?php echo e(number_format($weight * $price - $procurement->payments->sum('amount'), 0,'.',',')); ?></b><br>


                            </address>
                        </div>


                    </div>


                    <div class="row">
                        <?php if($procurement->security): ?>
                        <div class="col-md-6">
                            <div class="card card-outline card-info">

                                <div class="card-header">
                                    <div class="card-title">
                                        <div class="row">
                                            <div class="col-md-12 ">
                                                <i class="fas fa-file-invoice-dollar"></i>
                                                Security Details | <?php echo e($procurement->security->code); ?>

                                            </div>

                                            <div class="card-tools">
                                                <?php echo e($procurement->security->checkin_date); ?>

                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-condensed">
                                            <tbody>
                                            <tr>
                                                <th>Vehicle Number:</th>
                                                <td><?php echo e($procurement->security->vehicle_no); ?></td>
                                            </tr>
                                           <tr>
                                                <th>Number of Bags</th>
                                                <td><?php echo e($procurement->security->bags); ?></td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($procurement->weighbridge): ?>
                        <div class="col-md-6">
                            <div class="card card-outline card-info">

                                <div class="card-header">
                                    <div class="card-title">
                                        <div class="row">
                                            <div class="col-md-12 ">
                                                <i class="fas fa-file-invoice-dollar"></i>
                                                Weighbridge Details | <?php echo e($procurement->weighbridge->code); ?>

                                            </div>

                                            <div class="card-tools">
                                                <?php echo e($procurement->weighbridge->first_date); ?>

                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-condensed">
                                            <tbody>
                                            <tr>
                                                <th>Net Weight:</th>
                                                <td><?php echo e($procurement->weighbridge->weight); ?> tons</td>
                                            </tr>
                                            <tr>
                                                <th>Number of Bags</th>
                                                <td><?php echo e($procurement->weighbridge->bags); ?></td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if($procurement->quality): ?>
                        <div class="col-md-6">
                            <div class="card card-outline card-info">

                                <div class="card-header">
                                    <div class="card-title">
                                        <div class="row">
                                            <div class="col-md-12 ">
                                                <i class="fas fa-file-invoice-dollar"></i>
                                                Quality Details | <?php echo e($procurement->quality->code); ?>

                                            </div>

                                            <div class="card-tools">
                                                <?php echo e($procurement->quality->analysis_date); ?>

                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-condensed">
                                            <tbody>
                                            <tr>
                                                <th>Mositure:</th>
                                                <td><?php echo e($procurement->quality->moisture); ?> %</td>
                                            </tr>
                                            <tr>
                                                <th>Rejected Weight / Bags</th>
                                                <td><?php echo e($procurement->quality->rejected_weight); ?> tons / <?php echo e($procurement->quality->rejected_bags); ?></td>
                                            </tr>

                                            <tr>
                                                <th>Recommended Price/ton:</th>
                                                <td>₦ <?php echo e(number_format($procurement->quality->recommended_price,0, '.', ',')); ?> </td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <?php endif; ?>


                        <?php if($procurement->warehouse): ?>
                        <div class="col-md-6">
                            <div class="card card-outline card-info">

                                <div class="card-header">
                                    <div class="card-title">
                                        <div class="row">
                                            <div class="col-md-12 ">
                                                <i class="fas fa-file-invoice-dollar"></i>
                                                Warehouse Details | <?php echo e($procurement->warehouse->code); ?>

                                            </div>

                                            <div class="card-tools">
                                                <?php echo e($procurement->warehouse->receipt_date); ?>

                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-condensed">
                                            <tbody>
                                            <tr>
                                                <th>Weight:</th>
                                                <td><?php echo e($procurement->warehouse->weight); ?> tons</td>
                                            </tr>
                                            <tr>
                                                <th>Bags</th>
                                                <td><?php echo e($procurement->warehouse->bags); ?></td>
                                            </tr>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>
                       <?php endif; ?>




                        <div class="col-md-12">
                            <div class="card card-outline card-info">

                                <div class="card-header">
                                    <div class="card-title">
                                        <div class="row">
                                            <div class="col-md-12 ">
                                                <i class="fas fa-file-invoice-dollar"></i>
                                                Finance Details
                                            </div>

                                            <div class="card-tools">

                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-condensed">
                                            <tbody>

                                            <tr>
                                                <th>Bags</th>
                                                <td><?php echo e($procurement->warehouse ? $procurement->warehouse->bags: $procurement->expected_bags); ?></td>
                                            </tr>

                                            <tr>
                                                <th>Total Weight:</th>
                                                <td><?php echo e($procurement->warehouse ? $procurement->warehouse->weight : $procurement->expected_weight); ?> tons</td>
                                            </tr>

                                            <?php if($procurement->approval->approved_price): ?>
                                                <tr>
                                                    <th>Approved Price</th>
                                                    <td>₦ <?php echo e(number_format($procurement->approval->approved_price,0, '.', ',')); ?></td>
                                                </tr>
                                            <?php else: ?>
                                                <tr>
                                                    <th>Recommended Price</th>
                                                    <td>₦ <?php echo e(number_format($procurement->quality->recommended_price,0, '.', ',')); ?></td>
                                                </tr>
                                            <?php endif; ?>



                                            <tr>
                                                <th>Amount Due</th>
                                                <td>₦ <?php echo e(number_format($weight * $price,0, '.', ',')); ?></td>
                                            </tr>


                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>


                    </div> <!-- row -->

                        </div> <!-- invoice -->




                        </div>

                    </div>




                    <div class="row no-print">
                        <div class="col-12">
                            <a href="#" class="btn btn-warning">
                                <i class="fas fa-edit"></i>Edit Invoice
                            </a>

                            <button onclick="window.print()" class="btn btn-primary">
                                <i class="fas fa-print"></i> Print Invoice
                            </button>



                        </div>
                    </div>




                </div>

            </div>


        </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>








<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\hulhulde-erp\resources\views/procurement/show.blade.php ENDPATH**/ ?>