<?php $__env->startSection('title', 'Update Role | Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Update Role</h1> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <div class="container-fluid">
        <div id="errorBox"></div>
        <form action="<?php echo e(route('users.roles.update', $role->id)); ?>" method="POST" id="editform">
            <?php echo method_field('patch'); ?>
            <?php echo csrf_field(); ?>
            <div class="card">                
                <div class="card-body">
                    <div class="form-group">
                        <label for="name" class="form-label"> Name <span class="text-danger"> *</span></label>
                        <input type="text" name="name" id="name" class="form-control" placeholder="For e.g. Manager" value=<?php echo e(ucfirst($role->name)); ?>>
                    </div>
                    <label for="name" class="form-label"> Assign Permissions <span class="text-danger"> *</span></label>
                    <!--DataTable-->
                    <div class="table-responsive">
                        <table id="tblData" class="table table-bordered table-striped dataTable dtr-inline table-condensed">
                            <thead>
                                <tr>
                                    <th>
                                        <input type="checkbox" id="all_permission" name="all_permission">
                                    </th>
                                    <th>Name</th>
                                    <th>Guard</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
                <div class="card-footer">
                    <button id="save" class="btn btn-primary" >Save Role</button>
                </div>
            </div>
        </form>
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script>
    $.ajaxSetup({
        headers:{
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $(document).ready(function(){
        //check uncheck all function 
        $('[name="all_permission"]').on('click', function(){
            if($(this).is(":checked"))
            {
                $.each($('.permission'), function(){
                    if($(this).val()!="dashboard")
                    {
                        $(this).prop('checked', true); 
                    }
                });
            }else{
                $.each($('.permission'), function(){
                    if($(this).val()!="dashboard")
                    {
                        $(this).prop('checked', false); 
                    }
                });
            }
        });


        //validate
             var formvalidator = $('#editform').validate({
                    rules: {
                        name: {
                            required: true,
                        },                        
                    },
                    messages: {
                        name: {
                            name: "Please enter a valid role name",
                        },
                    },
                    errorElement: 'span',
                    errorPlacement: function (error, element) {
                        error.addClass('invalid-feedback');
                        element.closest('.form-group').append(error);
                    },
                    highlight: function (element, errorClass, validClass) {
                        $(element).addClass('is-invalid');
                    },
                    unhighlight: function (element, errorClass, validClass) {
                        $(element).removeClass('is-invalid');
                    }
                });



            
            //submit form

            $('#save').click(function(e){
                e.preventDefault();
 
                if(!formvalidator.form()){
                    return false;
                };

                var permissions = [];
                $('.permission:checked').each(function(i){
                        permissions[i] = $(this).val();
                });
                
                //submit
                var formData = {
                    name: $("#name").val(),
                    permission: permissions,                    
                };

                $.ajax({
                    type: "patch",
                    url: '<?php echo e(route('users.roles.update', $role)); ?>',
                    data: formData,
                    dataType: "json",
                    encode: true,
                    success:  function (response) {
                                if (response.success){
                                    $("#tblData").DataTable().ajax.reload();
                                    $('#newform').trigger('reset');
                                    sweetToast('', response.message, 'success', true);
                                    setTimeout(() => {
                                         window.location.href = '<?php echo e(route('users.roles.index')); ?>';
                                     }, 1000);

                                } else {
                                    sweetToast('', response.message, 'error', true);
                                }
                               },
                    error:     function (response){
                                     sweetToast('', 'Sorry, something went wrong! Please try again.', 'error', true); 
                               }
                
                });
                
            });



        var table = $('#tblData').DataTable({
            reponsive:true, processing:true, serverSide:true, autoWidth:false, bPaginate:false, bFilter:false,
            ajax:"<?php echo e(route('users.permissions.index', ['role_id' => $role->id])); ?>", 
            columns:[
                {data:'chkBox', name:'chkBox', orderable:false, searchable:false, className:'text-center'},
                {data:'name', name:'name'},
                {data:'guard_name', name:'guard_name'},
            ], 
            order:[[0, "desc"]]
        });
    });
    
   
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugins.Datatables', true); ?>
<?php $__env->startSection('plugins.Sweetalert2', true); ?>
<?php $__env->startSection('plugins.jQueryValidation', true); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\dev\hulhulde-erp\resources\views/users/roles/edit.blade.php ENDPATH**/ ?>